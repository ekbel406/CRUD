#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "equipement.h"

void
on_retour_vers_menu_equipement_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements, *fenetre_ajout_equipement;

	fenetre_ajout_equipement=lookup_widget(objet,"fenetre_ajout_equipement");
	

	gtk_widget_destroy(fenetre_ajout_equipement);
	menu_equipements=create_menu_equipements();
	gtk_widget_show(menu_equipements);
}

void
on_afficher_equipement_clicked         (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout_equipement;
GtkWidget *fenetre_afficher_equipement;
GtkWidget *treeview1_equipement;

fenetre_ajout_equipement=lookup_widget(objet,"fenetre_ajout_equipement");

gtk_widget_destroy(fenetre_ajout_equipement);
fenetre_afficher_equipement=lookup_widget(objet,"fenetre_afficher_equipement");
fenetre_afficher_equipement=create_fenetre_afficher_equipement();

gtk_widget_show(fenetre_afficher_equipement);

treeview1_equipement=lookup_widget(fenetre_afficher_equipement,"treeview1_equipement");

afficher_equipement(treeview1_equipement);
}



void
on_treeview1_equipement_row_activated  (GtkTreeView     *treeview1_equipement,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* identifianteq;
	gchar* typeeq;
	gchar* dateajouteq;
	gchar* etateq;
	gchar* statuseq;
	
	Equipement e;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview1_equipement);

	if(gtk_tree_model_get_iter(model, &iter, path))
	{
		//obtention des valeurs de la ligne selectionnée
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifianteq, 1, &typeeq, 2, &dateajouteq, 3, &etateq, 4, &statuseq,-1);
		//copie des valeurs dans la variable e de type equipement pour passer a la fonction de suppression 
		strcpy(e.IDequipement,identifianteq);
		strcpy(e.Typeequipement,typeeq);
		strcpy(e.Dateequipement,dateajouteq);
		strcpy(e.Etatequipement,etateq);
		strcpy(e.Statusequipement,statuseq);
		
		//appel de la fonction de suppression
		supprimer_equipement(e);
		//mise a jour de l'affichage de la treeview
		afficher_equipement(treeview1_equipement);
	}

}

void
on_retour_equipement_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements, *fenetre_afficher_equipement;

	fenetre_afficher_equipement=lookup_widget(objet,"fenetre_afficher_equipement");
	

	gtk_widget_destroy(fenetre_afficher_equipement);
	menu_equipements=create_menu_equipements();
	gtk_widget_show(menu_equipements);
}


void
on_afficher_equipements_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements;
GtkWidget *fenetre_afficher_equipement;
GtkWidget *treeview1_equipement;

menu_equipements=lookup_widget(objet,"menu_equipements");
gtk_widget_destroy(menu_equipements);

fenetre_afficher_equipement=lookup_widget(objet,"fenetre_afficher_equipement");
fenetre_afficher_equipement=create_fenetre_afficher_equipement();

gtk_widget_show(fenetre_afficher_equipement);

treeview1_equipement=lookup_widget(fenetre_afficher_equipement,"treeview1_equipement");

afficher_equipement(treeview1_equipement);
}


void
on_ajouter_equipements_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements, *fenetre_ajout_equipement;

	menu_equipements=lookup_widget(objet,"menu_equipements");
	

	gtk_widget_destroy(menu_equipements);
	fenetre_ajout_equipement=create_fenetre_ajout_equipement();
	gtk_widget_show(fenetre_ajout_equipement);
}

void
on_chercher_equipements_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements, *fenetre_rechercher_equipement;

	menu_equipements=lookup_widget(objet,"menu_equipements");
	

	gtk_widget_destroy(menu_equipements);
	fenetre_rechercher_equipement=create_fenetre_rechercher_equipement();
	gtk_widget_show(fenetre_rechercher_equipement);
}


void
on_supprimer_equipements_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements, *fenetre_supprimer_equipement;

	menu_equipements=lookup_widget(objet,"menu_equipements");
	

	gtk_widget_destroy(menu_equipements);
	fenetre_supprimer_equipement=create_fenetre_supprimer_equipement();
	gtk_widget_show(fenetre_supprimer_equipement);
}



void
on_modifier_equipements_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements, *fenetre_modifier_equipement;

	menu_equipements=lookup_widget(objet,"menu_equipements");
	

	gtk_widget_destroy(menu_equipements);
	fenetre_modifier_equipement=create_fenetre_modifier_equipement();
	gtk_widget_show(fenetre_modifier_equipement);
}

void
on_rechercher_equipement_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
char Id[20];
FILE *f=NULL;
	char chideq[20];
	char chtypeeq[20];
	char chdateeq[20];
	char chetat[20];
	char chstatus[20];
int trouv=-1;


id = lookup_widget (objet, "rech_id_equipement");
strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));


f=fopen("equipements.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",chideq,chtypeeq,chdateeq,chetat,chstatus)!=EOF)
{

if (strcmp(chideq,Id)==0)
{	strcat(chtypeeq," ");
	strcat(chtypeeq,chetat);
	strcat(chtypeeq," ");
	strcat(chtypeeq,chstatus);
sortie = lookup_widget(objet, "label19");
gtk_label_set_text(GTK_LABEL(sortie),chtypeeq);
trouv=1;
}
}
if (trouv!=1)
{
sortie = lookup_widget(objet, "label19");
gtk_label_set_text(GTK_LABEL(sortie),"Id n'existe pas");
}
}
}

void
on_retour_menu1_equipement_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_equipements, *fenetre_rechercher_equipement;

	fenetre_rechercher_equipement=lookup_widget(objet,"fenetre_rechercher_equipement");
	

	gtk_widget_destroy(fenetre_rechercher_equipement);
	menu_equipements=create_menu_equipements();
	gtk_widget_show(menu_equipements);
}

void
on_supprimer_equipement_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
char Id[20];

int trouv;
id = lookup_widget (objet, "supp_id_equipement");

strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));
trouv=Chercher_equipement (Id);

if (trouv==1)
{
Supprimer_equipement(Id);
sortie = lookup_widget(objet, "label23");
gtk_label_set_text(GTK_LABEL(sortie),"equipement supprimé avec succée!");
//printf("\n equipement supprimé avec succée!");
}
else 
{
sortie = lookup_widget(objet, "label23");
gtk_label_set_text(GTK_LABEL(sortie),"Id introuvable!");

}
}



void
on_retour_menu2_equipement_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supprimer_equipement, *menu_equipements;

	fenetre_supprimer_equipement=lookup_widget(objet,"fenetre_supprimer_equipement");
	

	gtk_widget_destroy(fenetre_supprimer_equipement);
	menu_equipements=create_menu_equipements();
	gtk_widget_show(menu_equipements);
}



void
on_modifier_equipement_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
GtkWidget *modifier_equipement, *modification_equipement;
char Id[20];

int trouv;
id = lookup_widget (objet, "modif_id_equipement");

strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));
trouv=Chercher_equipement (Id);

if (trouv==1)
{
sortie = lookup_widget(objet, "label37");
gtk_label_set_text(GTK_LABEL(sortie),"equipement trouvée!");
modifier_equipement=lookup_widget(objet,"modifier_equipement");
	

	//gtk_widget_destroy(modifier_equipement);
	modification_equipement=create_modification_equipement();
	gtk_widget_show(modification_equipement);
}
}



void
on_retour_menu3_equipement_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modifier_equipement, *menu_equipements;

	fenetre_modifier_equipement=lookup_widget(objet,"fenetre_modifier_equipement");
	

	gtk_widget_destroy(fenetre_modifier_equipement);
	menu_equipements=create_menu_equipements();
	gtk_widget_show(menu_equipements);
}


void
on_modif_chercher_equipement_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *id,*sortie;
GtkWidget *modifier_equipement, *modification_equipement;
char Id[20];

int trouv;
id = lookup_widget (objet, "modif2_id_equipement");

strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));
trouv=Chercher_equipement (Id);

if (trouv==1)
{
sortie = lookup_widget(objet, "label36");
gtk_label_set_text(GTK_LABEL(sortie),"equipement trouvée!");

}
else 
{
sortie = lookup_widget(objet, "label36");
gtk_label_set_text(GTK_LABEL(sortie),"Id introuvable!");

}
}



void
on_retour_menu4_equipement_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modification_equipement, *menu_equipements;

	modification_equipement=lookup_widget(objet,"modification_equipement");
	

	gtk_widget_destroy(modification_equipement);
	menu_equipements=create_menu_equipements();
	gtk_widget_show(menu_equipements);
}




void
on_modifier_confirmer_equipement_clicked 	(GtkWidget       *objet,
                                        	gpointer         user_data)
                                        
{
GtkWidget *id;
GtkWidget *input1, *input2, *input3, *input4, *input5;      //,chideq,chtypeeq,chdateeq,chetat,chstatus//
	char Id[20];
	char chideq[20];
	char chtypeeq[20];
	char chdateeq[20];
	char chetat[20];
	char chstatus[20];
FILE *f=NULL;
FILE *p=NULL;


id = lookup_widget (objet, "modif2_id_equipement");
strcpy(Id, gtk_entry_get_text(GTK_ENTRY(id)));

f=fopen("equipements.txt","r");
p=fopen("temp.txt","w");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",chideq,chtypeeq,chdateeq,chetat,chstatus)!=EOF)
{
if (strcmp(chideq,Id)==0)
{
input1=lookup_widget(objet,"nvideq"); 
input2=lookup_widget(objet,"nvtypeeq");
input3=lookup_widget(objet,"nvdateeq");
input4=lookup_widget(objet,"nvetat");
input5=lookup_widget(objet,"nvstatus");


strcpy(chideq,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(chtypeeq,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(chdateeq,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(chetat,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(chstatus,gtk_entry_get_text(GTK_ENTRY(input5)));

fprintf(p,"%s %s %s %s %s \n",chideq,chtypeeq,chdateeq,chetat,chstatus);
}
else
fprintf(p,"%s %s %s %s %s \n",chideq,chtypeeq,chdateeq,chetat,chstatus);
}
fclose(f);
fclose(p);
}
remove("equipements.txt");
rename("temp.txt","equipements.txt");
}


void
on_ajouter_equipement_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
Equipement e;

GtkWidget *input1, *input2, *input3, *input4, *input5;
GtkWidget *fenetre_ajout_equipement;

fenetre_ajout_equipement=lookup_widget(objet,"fenetre_ajout_equipement");

input1=lookup_widget(objet,"identifianteq"); 
input2=lookup_widget(objet,"typeeq");
input3=lookup_widget(objet,"dateajouteq");
input4=lookup_widget(objet,"etateq");
input5=lookup_widget(objet,"statuseq");


strcpy(e.IDequipement,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.Typeequipement,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.Dateequipement,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.Etatequipement,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.Statusequipement,gtk_entry_get_text(GTK_ENTRY(input5)));


ajouter_equipement(e);
}

