#include <gtk/gtk.h>




void
on_retour_equipement_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_equipements_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_equipements_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_equipements_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_equipements_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_equipements_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_vers_menu_equipement_clicked (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_afficher_equipement_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_equipement_row_activated  (GtkTreeView     *treeview1_equipement,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_menu1_equipement_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher_equipement_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_equipement_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu2_equipement_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_equipement_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu3_equipement_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_chercher_equipement_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu4_equipement_clicked     	(GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_confirmer_equipement_clicked 	(GtkWidget       *objet,
                                        	gpointer         user_data);
                                       

void
on_ajouter_equipement_clicked      	(GtkWidget       *objet,
                                        gpointer         user_data);
