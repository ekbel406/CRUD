#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *liste;
GtkWidget *window1;
Capteur c;
window1=lookup_widget(button,"windowCapteurs");
liste = lookup_widget(window1, "treeview1");
 afficher_capteur_alarmant (liste);
}

